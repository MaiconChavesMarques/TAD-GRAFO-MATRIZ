#include <stdio.h>
#include <stdlib.h>
#include "graph.h"

int main(){

    GRAPH *grafo1 = MyGraph(4);

    return 0;
}