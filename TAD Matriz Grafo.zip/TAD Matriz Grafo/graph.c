#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "graph.h"

struct graph_{
    int **matriz;
    int tamanho;
};

GRAPH *MyGraph(int numero_de_vertices){
    GRAPH *my_graph = (GRAPH*) malloc (sizeof(GRAPH));
    if (my_graph == NULL){
        printf("Não foi possível alocar memória\n");
        exit(1);
    }
    int a,b;
    a = numero_de_vertices;
    b = 2*numero_de_vertices;

    if ((my_graph->matriz = (int**) malloc (a*sizeof(int*))) == NULL){
        printf("Não foi possível alocar memória\n");
        exit(1);
    }
    for(int i=0; i<a; i++){
        if ((my_graph->matriz[i] = (int*) malloc (b*sizeof(int))) == NULL){
            printf("Não foi possível alocar memória\n");
            exit(1);
        }
    }
    
    for(int i = 0; i<a; i++){
        for(int j = 0; j<b; j++){
            my_graph->matriz[i][j]=0;
        }
    }

    for(int i = 0; i<a; i++){
        for(int j = 0; j<b; j++){
            printf("%d ", my_graph->matriz[i][j]);
            if (j+1==b){
                printf("\n");
            }
        }
    }

    return my_graph;
}

bool add_vertex(GRAPH *graph, int vertice01){

}


bool remove_vertex(GRAPH *graph, int vertice01){

}


bool add_edge(GRAPH *graph, int vertice01, int vertice02, int peso){

}


bool exist_edge(GRAPH *graph, int vertice01, int vertice02){

}


int* get_adj_vertex(GRAPH *graph, int vertice01){

}


bool remove_edge(GRAPH *graph, int vertice01, int vertice02){

}


void print_info(GRAPH *graph){
    
}


int number_of_vertexs(GRAPH *graph){

}


bool remove_graph(GRAPH **graph){

} 


bool menor_peso_graph(GRAPH *graph){

} 


int** adjacency_matrix(GRAPH *graph){

} 



